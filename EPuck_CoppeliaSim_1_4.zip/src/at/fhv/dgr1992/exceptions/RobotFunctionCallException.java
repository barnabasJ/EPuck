package at.fhv.dgr1992.exceptions;

public class RobotFunctionCallException extends Exception{
    public RobotFunctionCallException(String msg){
        super(msg);
    }
}
