package at.fhv.dgr1992.exceptions;

public class SensorNotEnabledException extends Exception{
    public SensorNotEnabledException(String msg){
        super(msg);
    }
}
