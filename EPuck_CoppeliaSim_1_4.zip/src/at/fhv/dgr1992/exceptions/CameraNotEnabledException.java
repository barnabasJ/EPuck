package at.fhv.dgr1992.exceptions;

public class CameraNotEnabledException extends Exception{
    public CameraNotEnabledException(String msg){
        super(msg);
    }
}
