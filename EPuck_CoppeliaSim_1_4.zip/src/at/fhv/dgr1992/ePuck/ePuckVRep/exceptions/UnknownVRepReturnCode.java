package at.fhv.dgr1992.ePuck.ePuckVRep.exceptions;

public class UnknownVRepReturnCode extends Exception{
    public UnknownVRepReturnCode(String msg){
        super(msg);
    }
}
