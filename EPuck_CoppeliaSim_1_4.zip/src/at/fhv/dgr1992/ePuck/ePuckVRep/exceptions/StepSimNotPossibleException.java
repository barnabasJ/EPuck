package at.fhv.dgr1992.ePuck.ePuckVRep.exceptions;

public class StepSimNotPossibleException extends Exception{
    public StepSimNotPossibleException(String msg){
        super(msg);
    }
}
