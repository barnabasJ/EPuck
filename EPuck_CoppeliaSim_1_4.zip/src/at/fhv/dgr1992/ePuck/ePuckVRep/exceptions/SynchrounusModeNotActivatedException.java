package at.fhv.dgr1992.ePuck.ePuckVRep.exceptions;


public class SynchrounusModeNotActivatedException extends Exception{
    public SynchrounusModeNotActivatedException(){
        super();
    }

    public SynchrounusModeNotActivatedException(String msg){
        super(msg);
    }
}
