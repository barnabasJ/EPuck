package at.fhv.dgr1992.differentialWheels;


public interface CameraImageObserver {
    void cameraImageChanged(CameraImage cameraImage);
}
